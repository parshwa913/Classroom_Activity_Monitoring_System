Get the Docker image:

$ docker pull apache/kafka:4.0.0
Start the Kafka Docker container:

$ docker run -p 9092:9092 apache/kafka:4.0.0
Using GraalVM Based Native Apache Kafka Docker Image
Get the Docker image:

$ docker pull apache/kafka-native:4.0.0
Start the Kafka Docker container:

$ docker run -p 9092:9092 apache/kafka-native:4.0.0