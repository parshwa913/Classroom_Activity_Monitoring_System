"""CSV-driven Kafka producer.

Reads rows from a CSV file and produces JSON messages to Kafka.
Columns are auto-detected but can be overridden via env vars.
"""

import os
import asyncio
import time
import json
import csv
from typing import Dict, List, Optional
from aiokafka import AIOKafkaProducer

KAFKA_BROKERS = os.getenv("KAFKA_BROKERS", "kafka:9092")
TOPIC = os.getenv("KAFKA_TOPIC", "student-activity")
CSV_FILE = os.getenv("CSV_FILE", "/data/attendance_predictions.csv")
CSV_DELAY_SEC = float(os.getenv("CSV_DELAY_SEC", "0.5"))
CSV_LOOP = os.getenv("CSV_LOOP", "false").lower() in {"1", "true", "yes"}

# Optional explicit column mappings
COL_STUDENT = os.getenv("CSV_COL_STUDENT_ID")
COL_STATUS = os.getenv("CSV_COL_STATUS")
COL_CONF = os.getenv("CSV_COL_CONFIDENCE")
COL_TS = os.getenv("CSV_COL_TIMESTAMP")
# CSE-specific optional columns
COL_IMAGE = os.getenv("CSV_COL_IMAGE")
COL_ATT_PROB = os.getenv("CSV_COL_ATTENTIVE_PROB")
COL_NONATT_PROB = os.getenv("CSV_COL_NON_ATTENTIVE_PROB")

CANDIDATES = {
    "student": ["student_id", "student", "sid", "id"],
    "status": ["status", "state", "label", "prediction"],
    "confidence": ["confidence", "score", "prob", "probability"],
    "timestamp": ["timestamp", "ts", "time", "datetime", "date"],
    # CSE hints
    "image": ["image", "filename", "file", "path"],
    "att_prob": ["attentive_prob", "att_prob", "prob_attentive", "p_att"],
    "non_att_prob": ["non_attentive_prob", "non_att_prob", "prob_non_attentive", "p_nonatt"],
}


def _find_col(header: List[str], explicit: Optional[str], candidates: List[str]) -> Optional[str]:
    if explicit and explicit in header:
        return explicit
    lower = [h.lower() for h in header]
    for c in candidates:
        if c in lower:
            return header[lower.index(c)]
    return None


def _derive_student_from_image(image_val: str) -> Optional[str]:
    # Try to extract an ID-like token from filenames such as "S101_frame_0001.jpg" or paths
    import re, os as _os
    base = _os.path.basename(str(image_val))
    m = re.search(r"(S\d+|\d{3,})", base, re.IGNORECASE)
    return m.group(1).upper() if m else None


def row_to_event(row: Dict[str, str], cols: Dict[str, Optional[str]]) -> Dict:
    # student_id
    sid = row.get(cols["student"]) if cols.get("student") else None
    if not sid and cols.get("image") and row.get(cols["image"]):
        sid = _derive_student_from_image(row.get(cols["image"]))
    # status
    status = (row.get(cols["status"]) if cols["status"] else None) or "attentive"
    status = str(status).strip().lower()
    # Normalize to only two classes: attentive, non_attentive
    if status in {"attentive", "att", "a", "1", "true", "yes"}:
        status = "attentive"
    else:
        # map any other class (sleeping, phone, distracted, etc.) to non_attentive
        status = "non_attentive"
    # confidence
    conf = None
    # Prefer explicit confidence column if provided
    if cols.get("confidence") and row.get(cols["confidence"]) not in (None, ""):
        try:
            conf = round(float(row.get(cols["confidence"])), 4)
        except Exception:
            conf = None
    else:
        # Derive from attentive/non-attentive probabilities if present
        try:
            pa = float(row.get(cols["att_prob"])) if cols.get("att_prob") and row.get(cols["att_prob"]) not in (None, "") else None
            pn = float(row.get(cols["non_att_prob"])) if cols.get("non_att_prob") and row.get(cols["non_att_prob"]) not in (None, "") else None
        except Exception:
            pa = pn = None
        if pa is not None or pn is not None:
            if status == "attentive" and pa is not None:
                conf = round(pa, 4)
            elif status != "attentive" and pn is not None:
                conf = round(pn, 4)
    # timestamp
    ts = time.time()
    val = row.get(cols["timestamp"]) if cols["timestamp"] else None
    if val:
        v = str(val).strip()
        try:
            ts = float(v)
        except Exception:
            # try parse ISO-like without extra deps
            try:
                from datetime import datetime
                ts = datetime.fromisoformat(v.replace("Z", "")).timestamp()
            except Exception:
                ts = time.time()
    return {
        "student_id": sid or "unknown",
        "status": status,
        "confidence": conf,
        "timestamp": ts,
    }


async def produce_csv():
    if not os.path.exists(CSV_FILE):
        raise FileNotFoundError(f"CSV file not found at {CSV_FILE}")

    producer = AIOKafkaProducer(
        bootstrap_servers=KAFKA_BROKERS,
        value_serializer=lambda v: json.dumps(v).encode("utf-8"),
    )
    await producer.start()
    try:
        while True:
            with open(CSV_FILE, "r", newline="") as f:
                reader = csv.DictReader(f)
                header = reader.fieldnames or []
                cols = {
                    "student": _find_col(header, COL_STUDENT, CANDIDATES["student"]),
                    "status": _find_col(header, COL_STATUS, CANDIDATES["status"]),
                    "confidence": _find_col(header, COL_CONF, CANDIDATES["confidence"]),
                    "timestamp": _find_col(header, COL_TS, CANDIDATES["timestamp"]),
                    # CSE extras
                    "image": _find_col(header, COL_IMAGE, CANDIDATES["image"]),
                    "att_prob": _find_col(header, COL_ATT_PROB, CANDIDATES["att_prob"]),
                    "non_att_prob": _find_col(header, COL_NONATT_PROB, CANDIDATES["non_att_prob"]),
                }
                if not cols["student"]:
                    print("Warning: could not detect student_id column; defaulting to 'unknown'", flush=True)
                count = 0
                for row in reader:
                    event = row_to_event(row, cols)
                    await producer.send_and_wait(TOPIC, event)
                    count += 1
                    if count % 100 == 0:
                        print(f"Produced {count} messages from CSV...", flush=True)
                    await asyncio.sleep(CSV_DELAY_SEC)
                print(f"Finished pass over CSV, produced {count} messages.", flush=True)
            if not CSV_LOOP:
                break
    finally:
        await producer.stop()


if __name__ == "__main__":
    asyncio.run(produce_csv())
