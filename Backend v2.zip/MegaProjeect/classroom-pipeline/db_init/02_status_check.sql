ALTER TABLE activity
  DROP CONSTRAINT IF EXISTS activity_status_check,
  ADD CONSTRAINT activity_status_check CHECK (status IN ('attentive','non_attentive'));
